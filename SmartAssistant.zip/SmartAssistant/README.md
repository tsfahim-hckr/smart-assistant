# Smart Assistant — Android Studio Project

A starter, **fully working** Kotlin + Jetpack Compose project for a Google-Assistant-style
always-listening voice assistant, built and tuned for **OPPO A12 (ColorOS)**.

## What's already working out of the box
- Foreground service (`AssistantService.kt`) that keeps listening in a loop
- Wake word detection using Android's built-in `SpeechRecognizer` (says "hey assistant" → then takes your command)
- Text-to-Speech replies
- Command routing (`CommandProcessor.kt`): open apps, set alarm, web search, time
- **Call a saved contact by name** — say "call <any saved contact name>" and it looks that
  name up in your phone contacts and dials directly, no dialer screen (`CallManager.callContactByName`)
- **Answer/reject a ringing call by voice** — while the phone is ringing, saying
  "receive the call" / "pick up" answers it, and "reject the call" / "hang up"
  declines it — no wake word needed during a ring (`CallManager.handleRingingCommand`)
- Auto-restart after reboot (`BootReceiver.kt`)
- **Step-by-step permission onboarding** (`PermissionScreen.kt`, `PermissionHelper.kt`) —
  one explanation card + one system popup at a time, instead of a batch request that
  some OEM builds (ColorOS included) can silently drop
- Professional dark-themed Compose UI

## Building the APK — from a PC (Android Studio)
1. Open this folder in Android Studio, let Gradle sync.
2. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
3. APK lands at `app/build/outputs/apk/debug/app-debug.apk`

## Building the APK — from your PHONE (no PC needed)
This project includes `.github/workflows/build-apk.yml`, which builds the APK
automatically in GitHub's free cloud servers. Your phone only uploads the code
and downloads the finished APK — no heavy compiling happens on the phone itself.

**Steps (all doable from a mobile browser):**
1. Go to **github.com**, sign up / log in.
2. Tap **+ → New repository**, give it any name (e.g. `smart-assistant`), make it Public, create it.
3. On the new repo page, use **"uploading an existing file"** and upload this entire
   project folder's contents (keep the folder structure — most mobile browsers let you
   pick a whole folder from "Add file → Upload files").
   - If your browser's file picker won't let you select a folder, install **Termux**
     (from F-Droid) and push the project with `git` instead — see the note below.
4. Commit the files to the `main` branch.
5. Go to the **Actions** tab of your repo — a workflow run should start automatically
   (or tap **Run workflow** if it doesn't).
6. Wait for it to finish (green checkmark, a few minutes).
7. Open the finished run → scroll to **Artifacts** → tap **SmartAssistant-debug-apk** to download it.
8. The download is a `.zip` containing `app-debug.apk` — extract it with any file manager app, then tap the APK to install (allow "install from unknown sources" when asked).

**If your mobile browser can't upload a whole folder (Termux + git method):**
```bash
pkg install git unzip -y
termux-setup-storage
cd ~/storage/downloads
unzip SmartAssistant.zip
cd SmartAssistant
git init
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git add .
git commit -m "initial commit"
git push -u origin main
```
When it asks for a password, GitHub requires a **Personal Access Token** instead of
your real password — generate one at github.com → Settings → Developer settings →
Personal access tokens → paste it when prompted.

## CRITICAL: OPPO / ColorOS setup (do this or the assistant will die in the background)
1. **Settings → Battery → App Battery Management → Smart Assistant → Allow background activity**
2. **Settings → App Management → Smart Assistant → Autostart → Enable**
3. **Settings → Battery → More Battery Settings → turn OFF "Optimize battery usage"** for this app
4. Lock the app in Recents (tap the lock icon on its card in the multitasking view)

## Known limitations of this starter (by design, so you can extend it)
- **Wake word engine**: uses `SpeechRecognizer` in a restart loop — not as battery-efficient
  as a dedicated wake-word model. For production, swap in **Picovoice Porcupine**
  (https://picovoice.ai/docs/porcupine/).
- **SMS**: `CommandProcessor.handleSms()` is a placeholder — wire it to `SmsManager` +
  the same contact lookup `CallManager` already has.
- **Conversational AI**: anything not matched by keywords goes to `onUnhandled(text)` in
  `CommandProcessor` — plug the Claude API (or any LLM) in there.
- **Default Assistant app**: to fully replace Google Assistant system-wide, implement
  `VoiceInteractionService` (a bigger, more advanced step).

## Project structure
```
SmartAssistant/
├── .github/workflows/build-apk.yml   (cloud APK build)
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/smartassistant/
│       │   ├── MainActivity.kt
│       │   ├── PermissionScreen.kt
│       │   ├── PermissionHelper.kt
│       │   ├── AssistantService.kt
│       │   ├── CommandProcessor.kt
│       │   ├── CallManager.kt
│       │   ├── BootReceiver.kt
│       │   └── ui/theme/
│       └── res/
├── build.gradle.kts
└── settings.gradle.kts
```
