package com.example.smartassistant.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AccentBlue = Color(0xFF4C8DFF)
val AccentBlueDark = Color(0xFF2F5FCC)
val BackgroundDark = Color(0xFF0E1117)
val SurfaceDark = Color(0xFF1A1F2B)
val BackgroundLight = Color(0xFFF5F7FB)
val SurfaceLight = Color(0xFFFFFFFF)
val TextPrimaryDark = Color(0xFFEDEFF5)
val TextSecondaryDark = Color(0xFF9AA3B5)

private val DarkColors = darkColorScheme(
    primary = AccentBlue,
    secondary = AccentBlueDark,
    background = BackgroundDark,
    surface = SurfaceDark,
    onPrimary = Color.White,
    onBackground = TextPrimaryDark,
    onSurface = TextPrimaryDark
)

private val LightColors = lightColorScheme(
    primary = AccentBlueDark,
    secondary = AccentBlue,
    background = BackgroundLight,
    surface = SurfaceLight,
    onPrimary = Color.White,
    onBackground = Color(0xFF1A1F2B),
    onSurface = Color(0xFF1A1F2B)
)

@Composable
fun SmartAssistantTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}
