package com.example.smartassistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat

class CallManager(private val context: Context) {

    companion object {
        const val TAG = "CallManager"
        val ANSWER_PHRASES = listOf("receive the call", "receive call", "answer the call", "answer call", "pick up", "pick up the call")
        val REJECT_PHRASES = listOf("reject the call", "reject call", "decline the call", "hang up", "end the call")
    }

    private var isRinging = false
    private val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

    fun startMonitoringCallState() {
        val hasPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasPermission) {
            Log.w(TAG, "READ_PHONE_STATE not granted, cannot detect ringing calls")
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            telephonyManager.registerTelephonyCallback(
                context.mainExecutor,
                object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) {
                        isRinging = (state == TelephonyManager.CALL_STATE_RINGING)
                    }
                }
            )
        } else {
            @Suppress("DEPRECATION")
            telephonyManager.listen(object : android.telephony.PhoneStateListener() {
                @Suppress("DEPRECATION")
                override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                    isRinging = (state == TelephonyManager.CALL_STATE_RINGING)
                }
            }, android.telephony.PhoneStateListener.LISTEN_CALL_STATE)
        }
    }

    fun isPhoneRinging(): Boolean = isRinging

    fun handleRingingCommand(text: String): String? {
        if (!isRinging) return null
        val lower = text.lowercase()

        if (ANSWER_PHRASES.any { lower.contains(it) }) {
            return answerCall()
        }
        if (REJECT_PHRASES.any { lower.contains(it) }) {
            return rejectCall()
        }
        return null
    }

    private fun answerCall(): String {
        val hasPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ANSWER_PHONE_CALLS
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasPermission) return "I need the 'answer phone calls' permission to do that."

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                telecomManager.acceptRingingCall()
                "Call answered"
            } else {
                "Answering calls by voice needs Android 8.0 or higher."
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "answerCall failed", e)
            "I couldn't answer the call — permission was denied by the system."
        }
    }

    private fun rejectCall(): String {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                telecomManager.endCall()
                "Call declined"
            } else {
                "Declining calls by voice needs Android 9.0 or higher."
            }
        } catch (e: SecurityException) {
            "I couldn't decline the call — permission was denied by the system."
        }
    }

    fun callContactByName(spokenName: String): String {
        val hasContacts = ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
        val hasCallPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasContacts) return "I need Contacts permission to find $spokenName."

        val number = findNumberByName(spokenName)
            ?: return "I couldn't find a contact named $spokenName"

        return if (hasCallPermission) {
            try {
                val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                "Calling $spokenName"
            } catch (e: SecurityException) {
                "I found $spokenName's number but don't have permission to call directly."
            }
        } else {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
            "Opening dialer for $spokenName"
        }
    }

    private fun findNumberByName(spokenName: String): String? {
        val target = spokenName.trim().lowercase()
        val resolver = context.contentResolver
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )

        cursor?.use {
            val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) {
                val name = it.getString(nameIdx) ?: continue
                if (name.lowercase().contains(target) || target.contains(name.lowercase())) {
                    return it.getString(numberIdx)
                }
            }
        }
        return null
    }
}
