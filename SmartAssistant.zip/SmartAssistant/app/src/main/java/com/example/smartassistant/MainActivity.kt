package com.example.smartassistant

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.smartassistant.ui.theme.SmartAssistantTheme

class MainActivity : ComponentActivity() {

    private var showOnboarding by mutableStateOf(true)
    private var permissionGranted by mutableStateOf(false)

    private fun allPermissionsGranted(): Boolean = PermissionHelper.requiredPermissions().all {
        ContextCompat.checkSelfPermission(this, it.permission) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        intent.data = Uri.parse("package:$packageName")
        startActivity(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val alreadyGranted = allPermissionsGranted()
        permissionGranted = alreadyGranted
        showOnboarding = !alreadyGranted

        setContent {
            SmartAssistantTheme {
                if (showOnboarding) {
                    PermissionOnboardingScreen(
                        permissions = PermissionHelper.requiredPermissions(),
                        shouldShowRationale = { perm -> shouldShowRequestPermissionRationale(perm) },
                        onOpenSettings = { openAppSettings() },
                        onFinished = {
                            permissionGranted = allPermissionsGranted()
                            showOnboarding = false
                        }
                    )
                } else {
                    AssistantHomeScreen(
                        hasPermission = permissionGranted,
                        onRequestPermission = { showOnboarding = true },
                        onStartService = { startAssistantService() },
                        onStopService = { stopAssistantService() },
                        onRequestBatteryExemption = { requestBatteryOptimizationExemption() }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        permissionGranted = allPermissionsGranted()
    }

    private fun startAssistantService() {
        val intent = Intent(this, AssistantService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopAssistantService() {
        stopService(Intent(this, AssistantService::class.java))
    }

    private fun requestBatteryOptimizationExemption() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantHomeScreen(
    hasPermission: Boolean,
    onRequestPermission: () -> Unit,
    onStartService: () -> Unit,
    onStopService: () -> Unit,
    onRequestBatteryExemption: () -> Unit
) {
    var isActive by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Smart Assistant", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { /* open settings screen */ }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(Modifier.height(32.dp))

            Box(
                modifier = Modifier
                    .size(160.dp)
                    .clip(CircleShape)
                    .background(
                        if (isActive) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.surfaceVariant
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.Mic,
                    contentDescription = null,
                    tint = if (isActive) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(64.dp)
                )
            }

            Spacer(Modifier.height(20.dp))

            Text(
                text = if (isActive) "Always listening for \"Hey Assistant\"" else "Assistant is off",
                style = MaterialTheme.typography.titleLarge
            )

            Spacer(Modifier.height(32.dp))

            if (!hasPermission) {
                StatusCard(
                    title = "Permissions needed",
                    description = "Microphone, Contacts, and Phone permissions let the assistant hear you, call people by name, and answer calls by voice.",
                    buttonText = "Grant permissions",
                    onClick = onRequestPermission
                )
                Spacer(Modifier.height(16.dp))
            }

            StatusCard(
                title = "Battery optimization",
                description = "OPPO (ColorOS) kills background apps aggressively. Exempt Smart Assistant so it keeps listening.",
                buttonText = "Disable battery optimization",
                onClick = onRequestBatteryExemption
            )

            Spacer(Modifier.height(32.dp))

            Button(
                onClick = {
                    isActive = !isActive
                    if (isActive) onStartService() else onStopService()
                },
                enabled = hasPermission,
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isActive) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary
                )
            ) {
                Text(
                    if (isActive) "Stop Assistant" else "Start Assistant",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(Modifier.height(24.dp))

            Text(
                "Tip: On OPPO, also enable \"Autostart\" for this app under Settings > App Management, or the service may still be killed after the screen locks.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun StatusCard(title: String, description: String, buttonText: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleLarge.copy(fontSize = 16.sp))
            Spacer(Modifier.height(4.dp))
            Text(description, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
                Text(buttonText)
            }
        }
    }
}
