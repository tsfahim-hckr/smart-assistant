package com.example.smartassistant

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhoneForwarded
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

sealed class PermissionStepState {
    data class Asking(val index: Int) : PermissionStepState()
    data class PermanentlyDenied(val item: PermissionItem) : PermissionStepState()
    object AllGranted : PermissionStepState()
}

private fun iconFor(permission: String): ImageVector = when {
    permission.contains("RECORD_AUDIO") -> Icons.Filled.Mic
    permission.contains("CONTACTS") -> Icons.Filled.Contacts
    permission.contains("CALL_PHONE") -> Icons.Filled.Call
    permission.contains("PHONE_STATE") -> Icons.Filled.Phone
    permission.contains("ANSWER_PHONE_CALLS") -> Icons.Filled.PhoneForwarded
    else -> Icons.Filled.Notifications
}

@Composable
fun PermissionOnboardingScreen(
    permissions: List<PermissionItem>,
    shouldShowRationale: (String) -> Boolean,
    onOpenSettings: () -> Unit,
    onFinished: () -> Unit
) {
    var stepState by remember { mutableStateOf<PermissionStepState>(PermissionStepState.Asking(0)) }
    var pendingRequestPermission by remember { mutableStateOf<String?>(null) }

    val launcher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        val current = (stepState as? PermissionStepState.Asking)?.index ?: return@rememberLauncherForActivityResult
        val item = permissions[current]

        if (granted) {
            advance(current, permissions) { stepState = it }
        } else {
            val canAskAgain = shouldShowRationale(item.permission)
            if (!canAskAgain) {
                stepState = PermissionStepState.PermanentlyDenied(item)
            } else {
                stepState = PermissionStepState.Asking(current)
            }
        }
    }

    LaunchedEffect(pendingRequestPermission) {
        pendingRequestPermission?.let {
            delay(600)
            launcher.launch(it)
            pendingRequestPermission = null
        }
    }

    LaunchedEffect(stepState) {
        if (stepState is PermissionStepState.AllGranted) {
            delay(800)
            onFinished()
        }
    }

    Scaffold { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(targetState = stepState, label = "permission-step") { state ->
                when (state) {
                    is PermissionStepState.Asking -> {
                        val item = permissions[state.index]
                        PermissionStepCard(
                            item = item,
                            stepNumber = state.index + 1,
                            totalSteps = permissions.size,
                            onContinue = { pendingRequestPermission = item.permission }
                        )
                    }
                    is PermissionStepState.PermanentlyDenied -> {
                        PermanentlyDeniedCard(
                            item = state.item,
                            onOpenSettings = onOpenSettings,
                            onSkip = {
                                val idx = permissions.indexOf(state.item)
                                advance(idx, permissions) { stepState = it }
                            }
                        )
                    }
                    is PermissionStepState.AllGranted -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(72.dp)
                            )
                            Spacer(Modifier.height(16.dp))
                            Text("All set!", style = MaterialTheme.typography.headlineMedium)
                        }
                    }
                }
            }
        }
    }
}

private fun advance(
    fromIndex: Int,
    permissions: List<PermissionItem>,
    setState: (PermissionStepState) -> Unit
) {
    val next = fromIndex + 1
    setState(
        if (next < permissions.size) PermissionStepState.Asking(next)
        else PermissionStepState.AllGranted
    )
}

@Composable
private fun PermissionStepCard(
    item: PermissionItem,
    stepNumber: Int,
    totalSteps: Int,
    onContinue: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "Step $stepNumber of $totalSteps",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))

        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                iconFor(item.permission),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(Modifier.height(24.dp))
        Text(item.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            item.description,
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(Modifier.height(32.dp))
        Button(
            onClick = onContinue,
            shape = RoundedCornerShape(50),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text("Continue")
        }
    }
}

@Composable
private fun PermanentlyDeniedCard(
    item: PermissionItem,
    onOpenSettings: () -> Unit,
    onSkip: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "${item.title} permission was blocked",
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Android won't show the popup again for this one. Turn it on manually in Settings, then come back.",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onOpenSettings,
            shape = RoundedCornerShape(50),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text("Open Settings")
        }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = onSkip) {
            Text("Skip for now")
        }
    }
}
