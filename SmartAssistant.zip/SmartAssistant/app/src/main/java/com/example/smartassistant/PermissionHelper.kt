package com.example.smartassistant

import android.Manifest
import android.os.Build

data class PermissionItem(
    val permission: String,
    val title: String,
    val description: String
)

object PermissionHelper {

    fun requiredPermissions(): List<PermissionItem> {
        val list = mutableListOf(
            PermissionItem(
                Manifest.permission.RECORD_AUDIO,
                "Microphone",
                "Needed so the assistant can hear the wake word and your voice commands."
            ),
            PermissionItem(
                Manifest.permission.READ_CONTACTS,
                "Contacts",
                "Needed to find a saved contact's number when you say \"call <name>\"."
            ),
            PermissionItem(
                Manifest.permission.CALL_PHONE,
                "Phone calls",
                "Needed to place the call directly, instead of just opening the dialer."
            ),
            PermissionItem(
                Manifest.permission.READ_PHONE_STATE,
                "Phone state",
                "Needed to detect the moment your phone starts ringing."
            ),
            PermissionItem(
                Manifest.permission.ANSWER_PHONE_CALLS,
                "Answer calls",
                "Needed so saying \"receive the call\" can actually pick it up."
            )
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(
                PermissionItem(
                    Manifest.permission.POST_NOTIFICATIONS,
                    "Notifications",
                    "Needed to show the persistent \"Assistant is listening\" status bar icon."
                )
            )
        }
        return list
    }
}
