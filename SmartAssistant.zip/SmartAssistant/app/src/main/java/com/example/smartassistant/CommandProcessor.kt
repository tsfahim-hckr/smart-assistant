package com.example.smartassistant

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock

/**
 * Turns recognized speech text into real phone actions.
 * Keyword-based matching first (fast, offline, no API cost).
 * Anything unmatched falls back to `onUnhandled` so the caller
 * can route it to an LLM API for a conversational answer.
 */
class CommandProcessor(private val context: Context) {

    val callManager = CallManager(context)

    fun process(rawText: String, onUnhandled: (String) -> Unit): String {
        val text = rawText.lowercase().trim()

        // While the phone is ringing, "receive the call" / "reject the call" take priority
        // over every other command, and don't need the "call " prefix.
        callManager.handleRingingCommand(text)?.let { return it }

        return when {
            text.startsWith("call ") -> callManager.callContactByName(text.removePrefix("call ").trim())

            text.startsWith("open ") -> handleOpenApp(text.removePrefix("open ").trim())

            text.startsWith("text ") || text.startsWith("message ") ->
                handleSms(text)

            text.contains("set alarm") || text.contains("wake me up") ->
                handleAlarm(text)

            text.contains("search for") || text.startsWith("google ") ->
                handleWebSearch(text)

            text.contains("what time") -> {
                val time = java.text.SimpleDateFormat("hh:mm a").format(java.util.Date())
                "It's currently $time"
            }

            else -> {
                onUnhandled(rawText)
                ""
            }
        }
    }

    private fun handleOpenApp(appName: String): String {
        val pm = context.packageManager
        val apps = pm.getInstalledApplications(android.content.pm.PackageManager.GET_META_DATA)
        val match = apps.firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(appName)
        }
        return if (match != null) {
            val launchIntent = pm.getLaunchIntentForPackage(match.packageName)
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(launchIntent)
                "Opening $appName"
            } else "Found $appName but could not launch it."
        } else "I couldn't find an app called $appName"
    }

    private fun handleSms(text: String): String {
        return "SMS command recognized. Wire this to SmsManager once contact resolution is added."
    }

    private fun handleAlarm(text: String): String {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
        return "Opening alarm setup"
    }

    private fun handleWebSearch(text: String): String {
        val query = text.replace("search for", "").replace("google", "").trim()
        val intent = Intent(Intent.ACTION_WEB_SEARCH)
        intent.putExtra("query", query)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        return try {
            context.startActivity(intent)
            "Searching for $query"
        } catch (e: Exception) {
            "Could not perform the search."
        }
    }
}
